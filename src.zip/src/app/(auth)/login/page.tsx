import Image from "next/image";
import { LoginForm } from "./login-form";

export const metadata = { title: "Masuk" };

export default async function LoginPage({ searchParams }: PageProps<"/login">) {
  const sp = await searchParams;
  const next = typeof sp.next === "string" ? sp.next : undefined;
  const alasan = typeof sp.alasan === "string" ? sp.alasan : undefined;
  return (
    <main className="grid min-h-dvh lg:grid-cols-[1fr_minmax(480px,560px)]">
      <section className="relative hidden flex-col justify-between overflow-hidden bg-ink p-12 text-white lg:flex">
        <div className="flex items-center gap-3">
          <Image src="/brand/logo-al-azhar.png" alt="Logo Al Azhar 42 Summarecon Bandung" width={64} height={64} className="size-14 object-contain" priority />
          <span className="text-xl font-bold tracking-[0.12em]">TANSE</span>
        </div>
        <div className="max-w-md">
          <h1 className="text-[34px] font-semibold leading-[1.15] tracking-[-0.02em]">Catatan kedisiplinan yang rapi, terlacak, dan adil.</h1>
          <p className="mt-4 text-[15px] leading-relaxed text-white/65">
            Usulan guru, keputusan BK, dan pengesahan kepala sekolah tercatat dalam satu alur. Setiap perubahan status meninggalkan jejak.
          </p>
        </div>
        <dl className="grid max-w-md grid-cols-3 gap-6 border-t border-white/15 pt-6 text-[13px]">
          <div><dt className="text-white/50">Alur</dt><dd className="mt-1 font-medium">Usulan → Sah</dd></div>
          <div><dt className="text-white/50">Dokumen</dt><dd className="mt-1 font-medium">Privat</dd></div>
          <div><dt className="text-white/50">Jejak</dt><dd className="mt-1 font-medium">Audit trail</dd></div>
        </dl>
      </section>
      <section className="flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <Image src="/brand/logo-al-azhar.png" alt="Logo Al Azhar 42 Summarecon Bandung" width={56} height={56} className="size-12 object-contain" priority />
            <span className="text-lg font-bold tracking-[0.12em] text-ink">TANSE</span>
          </div>
          <h2 className="text-2xl font-semibold tracking-[-0.02em]">Masuk</h2>
          <p className="mt-1 text-sm text-ink-2">Gunakan akun yang diberikan admin sekolah.</p>
          {alasan === "sesi" && (
            <p role="status" className="mt-4 rounded-[10px] border border-warning/25 bg-warning-soft px-3 py-2 text-[13px] text-warning">
              Sesi berakhir atau akun tidak aktif. Silakan masuk kembali.
            </p>
          )}
          <LoginForm next={next} />
        </div>
      </section>
    </main>
  );
}
