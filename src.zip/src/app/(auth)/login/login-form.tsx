"use client";
import { useActionState } from "react";
import { loginAction } from "@/lib/actions/auth";
import { initialState } from "@/lib/actions/types";
import { Field, FormMessage, Input } from "@/components/ui/form";
import { SubmitButton } from "@/components/ui/submit-button";

export function LoginForm({ next }: { next?: string | undefined }) {
  const [state, action] = useActionState(loginAction, initialState);
  return (
    <form action={action} className="mt-6 space-y-4" noValidate>
      {next ? <input type="hidden" name="next" value={next} /> : null}
      <Field label="Email" htmlFor="email" error={state.errors?.email}>
        <Input id="email" name="email" type="email" autoComplete="email" required aria-invalid={!!state.errors?.email} aria-describedby={state.errors?.email ? "email-error" : undefined} />
      </Field>
      <Field label="Password" htmlFor="password" error={state.errors?.password}>
        <Input id="password" name="password" type="password" autoComplete="current-password" required aria-invalid={!!state.errors?.password} />
      </Field>
      <FormMessage state={state} />
      <SubmitButton className="w-full" pendingText="Memeriksa…">Masuk</SubmitButton>
    </form>
  );
}
